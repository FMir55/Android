package com.hank.sheeve;

import com.hank.sheeve.models.ProductModel;

import java.util.List;

/**
 * Created by user on 2015/10/21.
 */
public interface GetProductCallback {
    public abstract void done(List<ProductModel> returnedProduct);
}
