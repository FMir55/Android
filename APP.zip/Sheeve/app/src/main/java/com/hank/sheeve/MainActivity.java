package com.hank.sheeve;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.hank.sheeve.models.ActivityModel;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    public final static String TITLE_EXTRA="com.hank.sheeve._ID";

    Button bLogout,bAddExhibition,bUpload,bManage;
    UserLocalStore userLocalStore;
    ListView lvActivities;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bLogout=(Button) findViewById(R.id.bLogout);
        bUpload=(Button)findViewById(R.id.bUpload);
        bManage=(Button)findViewById(R.id.bManage);
        bAddExhibition=(Button)findViewById(R.id.bAddExhibition);
        lvActivities= (ListView)findViewById(R.id.lvActivities);

        bLogout.setOnClickListener(this);
        bUpload.setOnClickListener(this);
        bManage.setOnClickListener(this);
        bAddExhibition.setOnClickListener(this);

        userLocalStore = new UserLocalStore(this);
    }

    @Override
    protected void onStart(){
        super.onStart();

        if(authenticate()==true){
            showExhibittionList();
        }else{
            startActivity(new Intent(MainActivity.this, Login.class));
        }
    }

    private boolean authenticate(){
        return  userLocalStore.getUserLoggedIn();
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.bLogout:

                userLocalStore.cleanUserData();
                userLocalStore.setUserLoggedIn(false);

                startActivity(new Intent(this, Login.class));

                break;

            case R.id.bUpload:

                break;

            case R.id.bManage:

                break;

            case R.id.bAddExhibition:

                startActivity(new Intent(this, AddExhibition.class));
                break;
        }
    }

    private void showExhibittionList() {
        ServerRequests serverRequests = new ServerRequests(this);
        serverRequests.fetchExhibitionDataInBackground( new GetExhibitionCallback() {
            @Override
            public void done(final List<ActivityModel> returnedActivity) {
                if (returnedActivity == null) {
                    showErrorMessage();
                } else {
                    ActivityAdapter adapter = new ActivityAdapter(getApplicationContext(),R.layout.row,returnedActivity);
                    lvActivities.setAdapter(adapter);
                    lvActivities.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            ActivityModel activityModel=(ActivityModel)(lvActivities.getItemAtPosition(position));

                            Intent i =new Intent(MainActivity.this, ProductList.class);
                            i.putExtra(TITLE_EXTRA, activityModel.getTitle());
                            startActivity(i);
                        }
                    });

                }
            }
        });
    }

    private void showErrorMessage() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        dialogBuilder.setMessage("No Exhibition");
        dialogBuilder.setPositiveButton("OK", null);
        dialogBuilder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();

        if(id==R.id.action_refresh){
            return true;
        }

        return  super.onOptionsItemSelected(item);
    }
}

class ActivityAdapter extends ArrayAdapter{

    private List<ActivityModel> activityModelList;
    private int resource;
    private LayoutInflater inflater;
    public ActivityAdapter(Context context,int resource, List<ActivityModel> objects)
    {
        super(context,resource,objects);
        activityModelList = objects;
        this.resource=resource;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position,View convertView,ViewGroup parent){
        if(convertView == null){
            convertView=inflater.inflate(resource,null);
        }

        TextView tvActivity;
        TextView tvDate;

        tvActivity=(TextView) convertView.findViewById(R.id.tvActivity);
        tvDate=(TextView)convertView.findViewById(R.id.tvDate);

        tvActivity.setText(activityModelList.get(position).getTitle());
        tvDate.setText(activityModelList.get(position).getDate());

        return convertView;
    }
}

