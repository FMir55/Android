package com.hank.sheeve;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.hank.sheeve.models.ProductModel;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.List;

public class ProductList extends AppCompatActivity implements View.OnClickListener {

    public final static String TYPEP_EXTRA="com.hank.sheeve._ID";
    public final static String TITLEP_EXTRA="com.hank.sheeve._ID2";
    public final static String TITLEA_EXTRA="com.hank.sheeve._ID3";
    public final static String PSP_EXTRA="com.hank.sheeve._ID4";
    public final static String PIC_EXTRA="com.hank.sheeve._ID5";

    public static Context context;

    Button bBack2,bUpload2;
    ListView lvProduct;
    TextView tvActTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        // Create default options which will be used for every
        //  displayImage(...) call if no options will be passed to this method
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .cacheOnDisk(true)
        .build();
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
        .defaultDisplayImageOptions(defaultOptions)
        .build();
        ImageLoader.getInstance().init(config); // Do it on Application start

        tvActTitle=(TextView)findViewById(R.id.tvActTitle);
        bBack2=(Button)findViewById(R.id.bBack2);
        bUpload2=(Button)findViewById(R.id.bUpload2);

        lvProduct=(ListView)findViewById(R.id.lvProduct);

        tvActTitle.setText(getIntent().getStringExtra(MainActivity.TITLE_EXTRA));
        if (tvActTitle.getText().toString().length()<1)
            tvActTitle.setText(getIntent().getStringExtra(ShowProduct.TITLE_EXTRA));
        if (tvActTitle.getText().toString().length()<1)
            tvActTitle.setText(getIntent().getStringExtra(UploadProduct.TITLE_EXTRA));

        bBack2.setOnClickListener(this);
        bUpload2.setOnClickListener(this);

        context = getApplicationContext();
    }

    @Override
    protected void onStart() {
        super.onStart();
        showProductList();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.bBack2:
                startActivity(new Intent(this, MainActivity.class));
                break;

            case R.id.bUpload2:
                Intent i =new Intent(this, UploadProduct.class);
                i.putExtra(TITLEA_EXTRA, tvActTitle.getText().toString());
                startActivity(i);
                break;

        }
    }

    private void showProductList() {
        ServerRequests serverRequests = new ServerRequests(this);
        String titleA=tvActTitle.getText().toString();
        serverRequests.fetchProductDataInBackground(titleA,new GetProductCallback() {
            @Override
            public void done(List<ProductModel> returnedProduct) {
                if (returnedProduct == null) {
                    showErrorMessage();
                } else {
                    ProductAdapter adapter = new ProductAdapter(getApplicationContext(),R.layout.row2,returnedProduct);
                    lvProduct.setAdapter(adapter);
                    lvProduct.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            ProductModel productModel=(ProductModel)(lvProduct.getItemAtPosition(position));

                            Intent i =new Intent(ProductList.this, ShowProduct.class);
                            i.putExtra(TITLEA_EXTRA, tvActTitle.getText().toString());
                            i.putExtra(TITLEP_EXTRA, productModel.getTitleP());
                            i.putExtra(TYPEP_EXTRA, productModel.getTypeP());
                            i.putExtra(PSP_EXTRA, productModel.getPsP());
                            i.putExtra(PIC_EXTRA,productModel.getPicUIL());

                            startActivity(i);
                        }
                    });

                }
            }
        });
    }

    private void showErrorMessage() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ProductList.this);
        dialogBuilder.setMessage("No Product in the Activity");
        dialogBuilder.setPositiveButton("OK", null);
        dialogBuilder.show();
    }
}

class ProductAdapter extends ArrayAdapter{

    private List<ProductModel> productModelList;
    private int resource;
    private LayoutInflater inflater;

    public ProductAdapter(Context context,int resource, List<ProductModel> objects)
    {
        super(context,resource,objects);
        productModelList = objects;
        this.resource=resource;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position,View convertView,ViewGroup parent){
        ViewHolder holder=null;

        if(convertView == null){
            holder=new ViewHolder();
            convertView=inflater.inflate(resource,null);
            holder.ivProduct=(ImageView)convertView.findViewById(R.id.ivProduct);
            holder.tvTitleP=(TextView)convertView.findViewById(R.id.tvTitleP);
            holder.tvTypeP=(TextView)convertView.findViewById(R.id.tvTypeP);
            holder.tvPsP=(TextView)convertView.findViewById(R.id.tvPsP);
            convertView.setTag(holder);
        }else{
            holder=(ViewHolder)convertView.getTag();
        }

        final ProgressBar progressBar=(ProgressBar)convertView.findViewById(R.id.progressBar);

        // Then later, when you want to display image
        ImageLoader.getInstance().displayImage(productModelList.get(position).getPicUIL(), holder.ivProduct, new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {
                progressBar.setVisibility(View.GONE);
            }
        });

        holder.tvTitleP.setText(productModelList.get(position).getTitleP());
        holder.tvTypeP.setText("■" + productModelList.get(position).getTypeP());
        holder.tvPsP.setText(productModelList.get(position).getPsP());
        //ivProduct.setImageDrawable(productModelList.get(position).getPic());

        return convertView;
    }

    class ViewHolder{
        private TextView tvTitleP;
        private TextView tvTypeP;
        private TextView tvPsP;
        private ImageView ivProduct;
    }

}


