package com.hank.sheeve;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hank.sheeve.models.ActivityModel;

import java.util.Calendar;


public class AddExhibition extends AppCompatActivity implements View.OnClickListener {

    Button bBack,bAdd;
    EditText etTitle,etYear,etMonth,etDay,etPS;
    TextView tvRemaining;

    private TextWatcher TW2,twYear,twMonth,twDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exhibition);

        TW2=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(etPS.getText().length()>80)
                    s.delete(80,etPS.getText().length());
                tvRemaining.setText("剩餘"+(80-etPS.getText().length())+"字");
            }
        };

        twYear=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                Calendar now = Calendar.getInstance();
                if(s.length()>0)
                    if(Integer.valueOf(s.toString())> now.get(Calendar.YEAR)+5)
                        s.replace(0, s.length(), String.valueOf(now.get(Calendar.YEAR)));
            }
        };

        twMonth=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()>0)
                    if(Integer.valueOf(s.toString())> 12)
                        s.replace(0, s.length(), "12");
            }
        };

        twDay=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()>0)
                    if(Integer.valueOf(s.toString())> 31)
                        s.replace(0, s.length(), "31");
            }
        };

        bAdd=(Button)findViewById(R.id.bAdd);
        bBack=(Button)findViewById(R.id.bBack);
        etTitle=(EditText)findViewById(R.id.etTitle);
        etYear=(EditText)findViewById(R.id.etYear);
        etMonth=(EditText)findViewById(R.id.etMonth);
        etDay=(EditText)findViewById(R.id.etDay);
        etPS=(EditText)findViewById(R.id.etPS);
        tvRemaining=(TextView)findViewById(R.id.tvRemaining);

        bAdd.setOnClickListener(this);
        bBack.setOnClickListener(this);

        etPS.addTextChangedListener(TW2);
        etYear.addTextChangedListener(twYear);
        etMonth.addTextChangedListener(twMonth);
        etDay.addTextChangedListener(twDay);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bBack:
                startActivity(new Intent(this, MainActivity.class));
                break;

            case R.id.bAdd:
                String title=etTitle.getText().toString();

                String year=etYear.getText().toString();
                String month=etMonth.getText().toString();
                String day=etDay.getText().toString();
                String date=year+"/"+month+"/"+day;

                String ps=etPS.getText().toString();

                ActivityModel activity=new ActivityModel();
                activity.setTitle(title);
                activity.setDate(date);
                activity.setPs(ps);

                addedExhibition(activity);
                break;
        }
    }

    private void addedExhibition(ActivityModel activity) {
        ServerRequests serverRequests=new ServerRequests(this);
        serverRequests.storeAddedExhibitionInBackground(activity, new GetAddCallback() {
            @Override
            public void done(ActivityModel returnedActivity) {
                startActivity(new Intent(AddExhibition.this, MainActivity.class));
            }
        });
    }
}
