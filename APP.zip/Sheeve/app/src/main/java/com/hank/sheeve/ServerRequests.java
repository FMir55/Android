package com.hank.sheeve;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;

import com.hank.sheeve.models.ActivityModel;
import com.hank.sheeve.models.ProductModel;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by user on 2015/10/9.
 */
public class ServerRequests {

    ProgressDialog progressDialog;
    public  static  final  int CONNECTION_TIMEOUT=1000*15;
    public  static final String SERVER_ADDRESS="http://fmir55.comuv.com/";

    public ServerRequests(Context context){
        progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setTitle("Processing");
        progressDialog.setMessage("Please wait...");
    }

    public void storeUserDataInBackground(User user,GetUserCallback userCallback){
        progressDialog.show();
        new StoreUserDataAsyncTask(user,userCallback).execute();
    }

    public void fetchUserDataInBackground(User user,GetUserCallback userCallback){
        progressDialog.show();
        new fetchUserDataAsyncTask(user,userCallback).execute();
    }

    public void storeAddedExhibitionInBackground(ActivityModel activity,GetAddCallback addCallback){
        progressDialog.show();
        new StoredAddedExhibitionAsynTask(activity,addCallback).execute();
    }

    public void fetchExhibitionDataInBackground(GetExhibitionCallback exhibitionCallback){
        progressDialog.show();
        new fetchExhibitionDataAsyncTask(exhibitionCallback).execute();
    }

    public void fetchProductDataInBackground(String titleA, GetProductCallback productCallback){
        progressDialog.show();
        new fetchProductDataAsyncTask(titleA, productCallback).execute();
    }

    public class fetchProductDataAsyncTask extends AsyncTask<Void, Void , List<ProductModel>>{

        String titleA;
        GetProductCallback productCallback;

        public fetchProductDataAsyncTask(String titleA,GetProductCallback productCallback){
            this.titleA=titleA;
            this.productCallback=productCallback;
        }

        @Override
        protected List<ProductModel> doInBackground(Void... params){

            ArrayList<NameValuePair> dataToSend = new ArrayList<>();
            dataToSend.add(new BasicNameValuePair("titleA", this.titleA));

            HttpParams httpRequestParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpRequestParams, CONNECTION_TIMEOUT);
            HttpConnectionParams.setSoTimeout(httpRequestParams, CONNECTION_TIMEOUT);

            HttpClient client=new DefaultHttpClient(httpRequestParams);
            HttpPost post=new HttpPost(SERVER_ADDRESS +"FetchProductData.php");

            ProductModel productModel= new ProductModel();
            List<ProductModel> productModelList = new ArrayList<>();

            try {
                post.setEntity(new UrlEncodedFormEntity(dataToSend));
                HttpResponse httpResponse = client.execute(post);

                HttpEntity entity = httpResponse.getEntity();
                String result= EntityUtils.toString(entity);

                JSONArray jArray = new JSONArray(result);

                for(int i=0;i<jArray.length();i++) {
                    JSONObject jObject = jArray.getJSONObject(i);

                    if (jObject.length() == 0) {
                        productModelList=null;
                    } else {

                        productModel.setTitleP(jObject.getString("titleP"));
                        productModel.setCodeP(jObject.getInt("codeP"));
                        productModel.setTypeP(jObject.getString("typeP"));
                        productModel.setPsP(jObject.getString("psP"));

                        productModel.setPicUIL(jObject.getString("pic"));

                        /*
                        String url = jObject.getString("pic");
                        InputStream is = openConnection(url);
                        Bitmap bitmap = convertIS2Bitmap(is);
                        Drawable drawable = convertBitmap2Drawable(bitmap);

                        productModel.setPic(drawable);

                        */
                        productModel.setTitleAct(jObject.getString("titleAct"));

                        productModelList.add(productModel);

                        productModel=new ProductModel();
                    }
                }
            }catch (Exception e) {
                e.printStackTrace();
            }

            return productModelList;
        }

/*
            private InputStream openConnection(String urlStr){
            InputStream is = null;
            try {
                URL url = new URL(urlStr);//ftp:/...
                URLConnection con = url.openConnection();
                if(con instanceof HttpURLConnection){
                    //cast it into the HttpURLConnection
                    HttpURLConnection httpURLConnection = (HttpURLConnection)con;
                    int response=-1;
                    //connect
                    httpURLConnection.connect();
                    response = httpURLConnection.getResponseCode();
                    if(response==HttpURLConnection.HTTP_OK) {
                        is = httpURLConnection.getInputStream();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return is;
        }
        //Convert the IS to Bitmap
        private Bitmap convertIS2Bitmap(InputStream is){
            Bitmap bitmap = null;
            bitmap = BitmapFactory.decodeStream(is);
            return bitmap;
        }
        //Convert the Bitmap into the Drawable
        private Drawable convertBitmap2Drawable(Bitmap bitmap){
            Drawable drawable=null;
            drawable = new BitmapDrawable(ProductList.context.getResources(),bitmap);
            return drawable;
        }
        */

        @Override
        protected void onPostExecute(List<ProductModel> returnedProduct){
            progressDialog.dismiss();
            productCallback.done(returnedProduct);
            super.onPostExecute(returnedProduct);
        }
    }

    public class StoredAddedExhibitionAsynTask extends AsyncTask<Void, Void , Void>{

        ActivityModel activity;
        GetAddCallback addCallback;

        public StoredAddedExhibitionAsynTask(ActivityModel activity,GetAddCallback addCallback){
            this.activity=activity;
            this.addCallback=addCallback;
        }

        @Override
        protected Void doInBackground(Void... params){
            ArrayList<NameValuePair> dataToSend = new ArrayList<>();
            dataToSend.add(new BasicNameValuePair("title",activity.getTitle()));
            dataToSend.add(new BasicNameValuePair("date",activity.getDate()));
            dataToSend.add(new BasicNameValuePair("ps", activity.getPs()));

            HttpParams httpRequestParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpRequestParams, CONNECTION_TIMEOUT);
            HttpConnectionParams.setSoTimeout(httpRequestParams, CONNECTION_TIMEOUT);

            HttpClient client=new DefaultHttpClient(httpRequestParams);
            HttpPost post=new HttpPost(SERVER_ADDRESS+"AddExhibition.php");

            try {
                post.setEntity(new UrlEncodedFormEntity(dataToSend));
                client.execute(post);
            }catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid){
            progressDialog.dismiss();
            addCallback.done(null);
            super.onPostExecute(aVoid);
        }
    }

    public class StoreUserDataAsyncTask extends AsyncTask<Void, Void , Void>{

        User user;
        GetUserCallback userCallback;

        public StoreUserDataAsyncTask(User user,GetUserCallback userCallback){
            this.user=user;
            this.userCallback=userCallback;
        }

        @Override
        protected Void doInBackground(Void... params){
            ArrayList<NameValuePair> dataToSend = new ArrayList<>();
            dataToSend.add(new BasicNameValuePair("name",user.name));
            dataToSend.add(new BasicNameValuePair("age",user.age+""));
            dataToSend.add(new BasicNameValuePair("email", user.email));
            dataToSend.add(new BasicNameValuePair("password", user.password));

            HttpParams httpRequestParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpRequestParams, CONNECTION_TIMEOUT);
            HttpConnectionParams.setSoTimeout(httpRequestParams, CONNECTION_TIMEOUT);

            HttpClient client=new DefaultHttpClient(httpRequestParams);
            HttpPost post=new HttpPost(SERVER_ADDRESS+"Register.php");

            try {
                post.setEntity(new UrlEncodedFormEntity(dataToSend));
                client.execute(post);
            }catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid){
            progressDialog.dismiss();
            userCallback.done(null);
            super.onPostExecute(aVoid);
        }
    }

    public class fetchUserDataAsyncTask extends AsyncTask<Void, Void , User>{

        User user;
        GetUserCallback userCallback;

        public fetchUserDataAsyncTask(User user,GetUserCallback userCallback){
            this.user=user;
            this.userCallback=userCallback;
        }

        @Override
        protected User doInBackground(Void... params){
            ArrayList<NameValuePair> dataToSend = new ArrayList<>();
            dataToSend.add(new BasicNameValuePair("email", user.email));
            dataToSend.add(new BasicNameValuePair("password", user.password));

            HttpParams httpRequestParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpRequestParams, CONNECTION_TIMEOUT);
            HttpConnectionParams.setSoTimeout(httpRequestParams, CONNECTION_TIMEOUT);

            HttpClient client=new DefaultHttpClient(httpRequestParams);
            HttpPost post=new HttpPost(SERVER_ADDRESS +"FetchUserData.php");

            User returnedUser = null;

            try {
                post.setEntity(new UrlEncodedFormEntity(dataToSend));
                HttpResponse httpResponse = client.execute(post);

                HttpEntity entity = httpResponse.getEntity();
                String result= EntityUtils.toString(entity);
                JSONObject jObject = new JSONObject(result);

                if(jObject.length()==0){
                    returnedUser=null;
                }   else {
                    String name=jObject.getString("name");
                    int age = jObject.getInt("age");

                    returnedUser = new User(name,age,user.email,user.password);
                }

            }catch (Exception e) {
                e.printStackTrace();
            }

            return returnedUser;
        }

        @Override
        protected void onPostExecute(User returnedUser){
            progressDialog.dismiss();
            userCallback.done(returnedUser);
            super.onPostExecute(returnedUser);
        }
    }

    public class fetchExhibitionDataAsyncTask extends AsyncTask<Void, Void , List<ActivityModel>>{

        GetExhibitionCallback exhibitionCallback;

        public fetchExhibitionDataAsyncTask(GetExhibitionCallback exhibitionCallback){
            this.exhibitionCallback=exhibitionCallback;
        }

        @Override
        protected List<ActivityModel> doInBackground(Void... params){
            ArrayList<NameValuePair> dataToSend = new ArrayList<>();

            HttpParams httpRequestParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpRequestParams, CONNECTION_TIMEOUT);
            HttpConnectionParams.setSoTimeout(httpRequestParams, CONNECTION_TIMEOUT);

            HttpClient client=new DefaultHttpClient(httpRequestParams);
            HttpPost post=new HttpPost(SERVER_ADDRESS +"FetchExhibitionData.php");

            ActivityModel activityModel = new ActivityModel();
            List<ActivityModel> activityModelList = new ArrayList<>();

            try {
                post.setEntity(new UrlEncodedFormEntity(dataToSend));
                HttpResponse httpResponse = client.execute(post);

                HttpEntity entity = httpResponse.getEntity();
                String result= EntityUtils.toString(entity);

                JSONArray jArray = new JSONArray(result);

                for(int i=0;i<jArray.length();i++) {
                    JSONObject jObject = jArray.getJSONObject(i);


                    if (jObject.length() == 0) {
                        activityModelList=null;
                    } else {
                        activityModel.setTitle(jObject.getString("title"));
                        activityModel.setDate(jObject.getString("date"));
                        activityModel.setPs(jObject.getString("ps"));

                        activityModelList.add(activityModel);

                        activityModel=new ActivityModel();
                    }
                }
            }catch (Exception e) {
                e.printStackTrace();
            }

            return activityModelList;
        }

        @Override
        protected void onPostExecute(List<ActivityModel> returnedExhibition){
            progressDialog.dismiss();
            exhibitionCallback.done(returnedExhibition);
            super.onPostExecute(returnedExhibition);
        }
    }

}

