package com.hank.sheeve;

import com.hank.sheeve.models.ActivityModel;


/**
 * Created by user on 2015/10/19.
 */
public interface GetAddCallback {
    public abstract void done(ActivityModel returnedActivity);
}
