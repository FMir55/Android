package com.hank.sheeve;

import com.hank.sheeve.models.ActivityModel;

import java.util.List;

/**
 * Created by user on 2015/10/17.
 */
public interface GetExhibitionCallback {
    public abstract void done(List<ActivityModel> returnActivity);
}
