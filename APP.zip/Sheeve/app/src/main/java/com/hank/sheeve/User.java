package com.hank.sheeve;

/**
 * Created by user on 2015/10/9.
 */
public class User {
    String name,email,password;
    int age;

    public User (String name,int age,String email,String password){
        this.name=name;
        this.age=age;
        this.email=email;
        this.password=password;
    }

    public User(String email,String password){
        this.email=email;
        this.password=password;
        this.age=-1;
        this.name="";
    }
}
