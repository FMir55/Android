package com.hank.sheeve;

/**
 * Created by user on 2015/10/9.
 */
interface GetUserCallback {

    public abstract void done(User returnedUser);
}
