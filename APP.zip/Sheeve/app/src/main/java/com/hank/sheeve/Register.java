package com.hank.sheeve;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.util.Linkify;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity implements View.OnClickListener {

    Button bRegister;
    EditText etName,etAge,etEmail,etPassword;
    String email;
    TextView tvMessage;

    private TextWatcher twAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        twAge=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()>2)
                    if(Integer.valueOf(s.toString())> 150)
                        s.replace(0, s.length(), "150");
            }
        };

        etName=(EditText)findViewById(R.id.etName);
        etAge=(EditText)findViewById(R.id.etAge);
        etEmail=(EditText)findViewById(R.id.etEmail);
        etPassword=(EditText)findViewById(R.id.etPassword);
        bRegister=(Button)findViewById(R.id.bRegister);
        tvMessage= (TextView) findViewById(R.id.tvMessage);

        bRegister.setOnClickListener(this);

        etAge.addTextChangedListener(twAge);

        etEmail.setOnKeyListener(new EditText.OnKeyListener(){

            @Override
            public boolean onKey(View arg0, int arg1, KeyEvent arg2) {
// TODO Auto-generated method stub
                if (Linkify.addLinks(etEmail.getText(), Linkify.EMAIL_ADDRESSES))
                {
                    email=etEmail.getText().toString();
                    tvMessage.setText("Email輸入正確");
                }
                else
                {
                    email="";
                    tvMessage.setText("請完整輸入Mail");
                }
                return false;
            }
        });
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.bRegister:

                String name= etName.getText().toString();
                String password = etPassword.getText().toString();
                int age=Integer.parseInt(etAge.getText().toString());
                User user;

                if(email.length()>0 && etName.getText().length()>0 && etAge.getText().length()>0 &&etPassword.getText().length()>0) {
                    user = new User(name, age, email, password);
                }
                else{
                    Toast.makeText(getBaseContext(),"請填妥資料欄位",Toast.LENGTH_SHORT).show();
                    break;
                }

                registeredData(user);
                break;
        }
    }

    private void registeredData(User user) {
        ServerRequests serverRequests=new ServerRequests(this);
        serverRequests.storeUserDataInBackground(user, new GetUserCallback() {
            @Override
            public void done(User returnedUser) {
                startActivity(new Intent(Register.this,Login.class));
            }
        });
    }
}
