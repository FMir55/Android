package com.hank.sheeve;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class ShowProduct extends AppCompatActivity implements View.OnClickListener {

    public final static String TITLE_EXTRA="com.hank.sheeve._ID";

    Button bBack3;
    TextView tvType,tvTitleP,tvActP,tvPSP;
    ImageView ivPIC;
    ProgressBar progressBar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_product);

        bBack3=(Button)findViewById(R.id.bBack3);

        tvTitleP=(TextView)findViewById(R.id.tvTitleP);
        tvType=(TextView)findViewById(R.id.tvType);
        tvActP=(TextView)findViewById(R.id.tvActP);
        tvPSP=(TextView)findViewById(R.id.tvPSP);
        ivPIC=(ImageView)findViewById(R.id.ivPIC);

        progressBar2=(ProgressBar)findViewById(R.id.progressBar2);
        progressBar2.setVisibility(View.VISIBLE);

        tvType.setText(getIntent().getStringExtra(ProductList.TYPEP_EXTRA));
        tvTitleP.setText(getIntent().getStringExtra(ProductList.TITLEP_EXTRA));
        tvActP.setText(getIntent().getStringExtra(ProductList.TITLEA_EXTRA));
        tvPSP.setText(getIntent().getStringExtra(ProductList.PSP_EXTRA));

        bBack3.setOnClickListener(this);

        DownloadTask downloadTask = new DownloadTask();
        downloadTask.execute(getIntent().getStringExtra(ProductList.PIC_EXTRA));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.bBack3:
                Intent i =new Intent(this, ProductList.class);
                i.putExtra(TITLE_EXTRA, tvActP.getText().toString());
                startActivity(i);
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_show_product, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Connect to the Internet (URL), get back the InputStream from it.
    private InputStream openConnection(String urlStr){
        InputStream is = null;
        try {
            URL url = new URL(urlStr);//ftp:/...
            URLConnection con = url.openConnection();
            if(con instanceof HttpURLConnection){
                //cast it into the HttpURLConnection
                HttpURLConnection httpURLConnection = (HttpURLConnection)con;
                int response=-1;
                //connect
                httpURLConnection.connect();
                response = httpURLConnection.getResponseCode();
                if(response==HttpURLConnection.HTTP_OK) {
                    is = httpURLConnection.getInputStream();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return is;
    }
    //Convert the IS to Bitmap
    private Bitmap convertIS2Bitmap(InputStream is){
        Bitmap bitmap = null;
        bitmap = BitmapFactory.decodeStream(is);
        return bitmap;
    }
    //Convert the Bitmap into the Drawable
    private Drawable convertBitmap2Drawable(Bitmap bitmap){
        Drawable drawable=null;
        drawable = new BitmapDrawable(getResources(), bitmap);
        return drawable;
    }
    //put this long running task into the AysncTask
    private class DownloadTask extends AsyncTask<String, Void, Drawable> {
        @Override
        protected Drawable doInBackground(String... params) {
            String url = params[0];
            InputStream is = openConnection(url);
            Bitmap bitmap = convertIS2Bitmap(is);
            Drawable drawable = convertBitmap2Drawable(bitmap);
            return drawable;
        }

        @Override
        protected void onPostExecute(Drawable drawable) {
            progressBar2.setVisibility(View.GONE);
            ivPIC.setImageDrawable(drawable);
        }
    }
}
