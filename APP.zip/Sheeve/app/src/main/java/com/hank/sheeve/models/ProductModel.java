package com.hank.sheeve.models;

import android.graphics.drawable.Drawable;

/**
 * Created by user on 2015/10/21.
 */
public class ProductModel {
    private String titleP;
    private int codeP;
    private String typeP;
    private String psP;
    private Drawable pic;
    private String picUIL;
    private String titleAct;

    public String getTitleP(){
        return titleP;
    }

    public void setTitleP(String titleP){
        this.titleP=titleP;
    }

    public int getCodeP(){
        return  codeP;
    }

    public void setCodeP(int codeP){
        this.codeP=codeP;
    }

    public String getTypeP(){
        return typeP;
    }

    public void setTypeP(String typeP){
        this.typeP=typeP;
    }

    public String getPsP(){
        return psP;
    }

    public void setPsP(String psP){
        this.psP=psP;
    }

    public Drawable getPic(){
        return pic;
    }

    public void setPic(Drawable pic){
        this.pic=pic;
    }

    public String getPicUIL() {
        return picUIL;
    }

    public void setPicUIL(String picUIL) {
        this.picUIL = picUIL;
    }

    public String getTitleAct(){
        return titleAct;
    }

    public void setTitleAct(String titleAct){
        this.titleAct=titleAct;
    }


}
