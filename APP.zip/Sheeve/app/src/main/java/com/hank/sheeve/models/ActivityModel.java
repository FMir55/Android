package com.hank.sheeve.models;

/**
 * Created by user on 2015/10/16.
 */
public class ActivityModel {

    private String title;
    private String date;
    private String ps;

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title=title;
    }

    public String getDate(){
        return date;
    }

    public void setDate(String date){
        this.date=date;
    }

    public String getPs(){
        return ps;
    }

    public void setPs(String ps){
        this.ps=ps;
    }
}
